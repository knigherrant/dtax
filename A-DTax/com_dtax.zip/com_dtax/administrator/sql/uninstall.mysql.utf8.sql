DROP TABLE IF EXISTS `#__dtax_bibles`;
DROP TABLE IF EXISTS `#__dtax_comments`;
DROP TABLE IF EXISTS `#__dtax_config`;
DROP TABLE IF EXISTS `#__dtax_events`;
DROP TABLE IF EXISTS `#__dtax_links`;
DROP TABLE IF EXISTS `#__dtax_profiles`;
DROP TABLE IF EXISTS `#__dtax_requests`;
DROP TABLE IF EXISTS `#__dtax_warriors`;





