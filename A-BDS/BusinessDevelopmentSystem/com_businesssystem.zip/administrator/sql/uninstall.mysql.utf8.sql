DROP TABLE IF EXISTS `#__businesssystem_company`;
DROP TABLE IF EXISTS `#__businesssystem_config`;
DROP TABLE IF EXISTS `#__businesssystem_cpas`;
DROP TABLE IF EXISTS `#__businesssystem_customers`;
DROP TABLE IF EXISTS `#__businesssystem_expenses`;
DROP TABLE IF EXISTS `#__businesssystem_invoices`;
DROP TABLE IF EXISTS `#__businesssystem_links`;
DROP TABLE IF EXISTS `#__businesssystem_locations`;
DROP TABLE IF EXISTS `#__businesssystem_mileages`;
DROP TABLE IF EXISTS `#__businesssystem_receipts`;
DROP TABLE IF EXISTS `#__businesssystem_taxreturns`;




